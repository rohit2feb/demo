# Exercise 01: Register for Trial Account on SAP Cloud Platform Cloud Foundry

## Estimated time

:clock4: 5 minutes

## Exercise description

Follow this [step-by-step](http://go.sap.com/developer/tutorials/hcp-create-trial-account.html) tutorial to a trial account.
